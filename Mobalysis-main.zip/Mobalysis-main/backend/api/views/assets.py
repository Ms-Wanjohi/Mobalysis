base_url = "https://earlygamestore.z13.web.core.windows.net"
current_version = "11.24.1"
